public class Lab1Task {
    public static void main(String[] args){
        var name="Kijun"; //replace with your name
        var id=20319196; //replace with your ID
        System.out.println("I am "+ name+ " and my student ID is:"+id);
    }
}
